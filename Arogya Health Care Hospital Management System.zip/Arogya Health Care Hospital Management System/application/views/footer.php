    <div style="clear:both;color:#aaa; padding:20px;">

    	<hr /><center>&copy; <?php echo date ('Y'); ?> A hospitals management case study application</center>

    </div>